(function(e) {
  e('.swatch :radio').change(function() {
    var optionIndex = e(this).closest('.swatch').attr('data-option-index');
    var optionValue = e(this).val();
    e(this)
      .closest('form')
      .find('.single-option-selector')
      .eq(optionIndex)
      .val(optionValue)
      .trigger('change');
  }); 
  
    e(document).ready(function() {
        t.init()
    });
  
  
     e(document).on("click touchstart", function(n) {
            var r = e(".quick-view");
            var i = e("#slidedown-cart");
            var s = e("#ToggleDown");
            var o = e("#email-modal .modal-window");
        
            if (!r.is(n.target) && r.has(n.target).length === 0 && !i.is(n.target) && i.has(n.target).length === 0 && !s.is(n.target) && s.has(n.target).length === 0 && !o.is(n.target) && o.has(n.target).length === 0 ) {
                t.closeQuickViewPopup();
                t.closeDropdownCart();
                t.closeEmailModalWindow();
               
            }
        })
    
    e(document).keyup(function(n) {
        if (n.keyCode == 27) {
            t.closeQuickViewPopup();
            t.closeDropdownCart();
            clearTimeout(t.KidsTimeout);
            if (e(".modal").is(":visible")) {
                e(".modal").fadeOut(500)
            }
        }
    });
    var t = {
        KidsTimeout: null,
        isSidebarAjaxClick: false,
        init: function() {    
            this.initQuickView();
            this.initAddToCart();
            this.initModal();
            this.initProductAddToCart();
            this.initDropDownCart();
            this.initWishlist();
            this.initProductWishlist();     
            this.initProductMoreview();
            this.initelevateZoom();
           
        },
        initWishlist: function() {
            e(".item-row button.wishlist").click(function(n) {
                n.preventDefault();
                var r = e(this).parent();
                var i = r.parents(".item-row");
                e.ajax({
                    type: "POST",
                    url: "/contact",
                    data: r.serialize(),
                    beforeSend: function() {
                        t.showLoading()
                    },
                    success: function(n) {
                        t.hideLoading();                     
                       var o = i.find(".product-thumb img.product-main-img").attr("src");
                       e(".ajax-success-modal").find(".added-to-wishlist").show();
                       e(".ajax-success-modal").find(".added-to-cart").hide();
                       e(".ajax-success-modal").find(".ajax-product-image").attr("src", o);
                       t.showModal(".ajax-success-modal")
                    },
                    error: function(n, r) {
                        t.hideLoading();
                        e(".loading-modal").hide();
                        e(".ajax-error-message").text(e.parseJSON(n.responseText).description);
                        t.showModal(".ajax-error-modal")
                    }
                })
            })
        },
      initelevateZoom: function() {
            if (e("#product-featured-image").length > 0) {        
                    e("#product-featured-image").elevateZoom({
                        gallery: "ProductThumbs",
                        cursor: "pointer",
                        galleryActiveClass: "active",
                        imageCrossfade: true,
                        scrollZoom: true,                      
                        onImageSwapComplete: function() {
                            e(".zoomWrapper div").hide()
                        },
                        loadingIcon: window.loading_url
                    });
                    e("#product-featured-image").bind("click", function(t) {
                        var n = e("#product-featured-image").data("elevateZoom");
                        e.fancybox(n.getGalleryList());
                        return false
                    })
            }
        
        },
        initProductWishlist: function() {
            e(".product-page.wishlist").click(function(n) {
                n.preventDefault();
                var r = e(this).parent();
                var i = r.parents(".grid-item");
                e.ajax({
                    type: "POST",
                    url: "/contact",
                    data: r.serialize(),
                    beforeSend: function() {
                        t.showLoading()
                    },
                    success: function(n) {
                        t.hideLoading();                  
                       var o = e("#product-featured-image").attr("src");
                        e(".ajax-success-modal").find(".added-to-wishlist").show();
                        e(".ajax-success-modal").find(".added-to-cart").hide();
                        e(".ajax-success-modal").find(".ajax-product-image").attr("src", o);
                        t.showModal(".ajax-success-modal")
                    },
                    error: function(n, r) {
                        t.hideLoading();
                        e(".loading-modal").hide();
                        e(".ajax-error-message").text(e.parseJSON(n.responseText).description);
                        t.showModal(".ajax-error-modal")
                    }
                })
            })
        },
      
        showModal: function(n) {
            e(n).fadeIn(500);
            t.KidsTimeout = setTimeout(function() {
                e(n).fadeOut(500)
            }, 5e3)
        },
        checkItemsInDropdownCart: function() {
            if (e("#slidedown-cart .mini-products-list").children().length > 0) {
                e("#slidedown-cart .no-items").hide();
                e("#slidedown-cart .has-items").show()
            } else {
                e("#slidedown-cart .has-items").hide();
                e("#slidedown-cart .no-items").show()
            }
        },
        initModal: function() {
            e(".continue-shopping").click(function() {
                clearTimeout(t.KidsTimeout);
                e(".ajax-success-modal").fadeOut(500)
            });
            e(".close-modal, .overlay").click(function() {
                clearTimeout(t.KidsTimeout);
                e(".ajax-success-modal").fadeOut(500)
            })
        },
        initDropDownCart: function() {
            if (window.dropdowncart_type == "click") {
                e("#ToggleDown").click(function() {
                    if (e("#slidedown-cart").is(":visible")) {
                        e("#slidedown-cart").slideUp("fast")
                    } else {
                        e("#slidedown-cart").slideDown("fast")
                    }
                })
            } else {
                if (!("ontouchstart" in document)) {
                    e("#ToggleDown").hover(function() {
                        if (!e("#slidedown-cart").is(":visible")) {
                            e("#slidedown-cart").slideDown("fast")
                        }
                    });
                    e(".wrapper-top-cart").mouseleave(function() {
                        e("#slidedown-cart").slideUp("fast")
                    })
                } else {
                    e("#ToggleDown").click(function() {
                        if (e("#slidedown-cart").is(":visible")) {
                            e("#slidedown-cart").slideUp("fast")
                        } else {
                            e("#slidedown-cart").slideDown("fast")
                        }
                    })
                }
            }
            t.checkItemsInDropdownCart();
            e("#slidedown-cart .no-items a").click(function() {
                e("#slidedown-cart").slideUp("fast")
            });
            e("#slidedown-cart .btn-remove").click(function(n) {
                n.preventDefault();
                var r = e(this).parents(".item").attr("id");
                r = r.match(/\d+/g);
                Shopify.removeItem(r, function(e) {
                    t.doUpdateDropdownCart(e)
                })
            })
        },
        closeDropdownCart: function() {
            if (e("#slidedown-cart").is(":visible")) {
                e("#slidedown-cart").slideUp("fast")
            }
        },
       
        
        initProductAddToCart: function() {
            if (e("#AddToCart").length > 0) {
                e("#AddToCart").click(function(n) {
                    n.preventDefault();
                    if (e(this).attr("disabled") != "disabled") {
                        if (!window.ajax_cart) {
                            e(this).closest("form").submit()
                        } else {
                            var r = e("#AddToCartForm select[name=id]").val();
                            if (!r) {
                                r = e("#AddToCartForm input[name=id]").val()
                            }
                            var i = e("#AddToCartForm input[name=quantity]").val();
                            if (!i) {
                                i = 1
                            }                          
                            var o = e("#product-featured-image").attr("src");
                            t.doAjaxAddToCart(r, i, o)
                        }
                    }
                    return false
                })
            }
        },
        initAddToCart: function() {
            if (e(".add-cart-btn").length > 0) {
                e(".add-cart-btn").click(function(n) {
                    n.preventDefault();
                    if (e(this).attr("disabled") != "disabled") {
                        var r = e(this).parents(".item-row");
                        var i = e(r).attr("id");
                        i = i.match(/\d+/g);
                        if (!window.ajax_cart) {
                            e("#cart-form-" + i).submit()
                        } else {
                            var s = e("#cart-form-" + i + " select[name=id]").val();
                            if (!s) {
                                s = e("#cart-form-" + i + " input[name=id]").val()
                            }
                            var o = e("#cart-form-" + i + " input[name=quantity]").val();
                            if (!o) {
                                o = 1
                            }
                           var a = e(r).find(".product-thumb img.product-main-img").attr("src");
                            t.doAjaxAddToCart(s, o, a)
                        }
                    }
                    return false
                })
            }
        },
        showLoading: function() {
            e(".loading-modal").show()
        },
        hideLoading: function() {
            e(".loading-modal").hide()
        },
        doAjaxAddToCart: function(n, r, a) {
            e.ajax({
                type: "post",
                url: "/cart/add.js",
                data: "quantity=" + r + "&id=" + n,
                dataType: "json",
                beforeSend: function() {
                    t.showLoading()
                },
                success: function(n) {
                    t.hideLoading();                    
                    t.showModal(".ajax-success-modal");
                     e(".ajax-success-modal").find(".ajax-product-image").attr("src", a);
                     e(".ajax-success-modal").find(".added-to-wishlist").hide();
                     e(".ajax-success-modal").find(".added-to-cart").show();
                    t.updateDropdownCart()
                },
                error: function(n, r) {
                    t.hideLoading();
                    e(".ajax-error-message").text(e.parseJSON(n.responseText).description);
                    t.showModal(".ajax-error-modal")
                }
            })
        },
        initQuickView: function() {
            e(".quick-view-text").click(function() {
                var n = e(this).attr("id");
                Shopify.getProduct(n, function(n) {
                    var r = e("#quickview-template").html();
                    e(".quick-view").html(r);
                    var i = e(".quick-view");
                    var s = n.description.replace(/(<([^>]+)>)/ig, "");
                    s = s.split(" ").splice(0, 30).join(" ") + "...";
                    i.find(".product-title a").text(n.title);
                    i.find(".product-title a").attr("href", n.url);
                    if (i.find(".product-inventory span").length > 0) {
                        var o = n.variants[0].inventory_quantity;
                        if (o > 0) {
                            if (n.variants[0].inventory_management != null) {
                                i.find(".product-inventory span").text(o + " in stock")
                            } else {
                                i.find(".product-inventory span").text("Many in stock")
                            }
                        } else {
                            i.find(".product-inventory span").text("Out of stock")
                        }
                    }
                    i.find(".product-description").text(s);
                    i.find(".price").html(Shopify.formatMoney(n.price, window.money_format));
                    i.find(".product-item").attr("id", "product-" + n.id);
                    i.find(".variants").attr("id", "product-actions-" + n.id);
                    i.find(".variants select").attr("id", "product-select-" + n.id);
                    if (n.compare_at_price > n.price) {
                        i.find(".compare-price").html(Shopify.formatMoney(n.compare_at_price_max, window.money_format)).show();
                        i.find(".price").addClass("on-sale")
                    } else {
                        i.find(".compare-price").html("");
                        i.find(".price").removeClass("on-sale")
                    }
                    if (!n.available) {
                        i.find("select, input, .total-price, .dec, .inc, .variants label").remove();
                        i.find(".add-cart-btn").text("Unavailable").addClass("disabled").attr("disabled", "disabled");
                    } else {
                        i.find(".total-price .price").html(Shopify.formatMoney(n.price, window.money_format));
                         t.createQuickViewVariants(n, i)
                        
                    }
                    i.find(".button").on("click", function() {
                        var n = i.find(".quantity").val(),
                            r = 1;
                        if (e(this).text() == "+") {
                            r = parseInt(n) + 1
                        } else if (n > 1) {
                            r = parseInt(n) - 1
                        }
                        i.find(".quantity").val(r);
                    });
                  
                    t.loadQuickViewSlider(n, i);
                    t.initQuickviewAddToCart();
                    e(".quick-view").fadeIn(500);
                   
                });
                return false
            });
             e(".quick-view .overlay, .close-window").live("click", function() {
                t.closeQuickViewPopup();
                return false
            })
           
        },
        
        initQuickviewAddToCart: function() {
            if (e(".quick-view .add-cart-btn").length > 0) {
                e(".quick-view .add-cart-btn").click(function() {
                    var n = e(".quick-view select[name=id]").val();
                    if (!n) {
                        n = e(".quick-view input[name=id]").val()
                    }
                    var r = e(".quick-view input[name=quantity]").val();
                    if (!r) {
                        r = 1
                    }
                   
                    var a = e(".quick-view .quickview-featured-image img").attr("src");                 
                    t.doAjaxAddToCart(n, r, a);
                    t.closeQuickViewPopup()
                })
            }
        },
        updateDropdownCart: function() {
            Shopify.getCart(function(e) {
                t.doUpdateDropdownCart(e)
            })
        },
        doUpdateDropdownCart: function(n) {
            var r = '<li class="item" id="cart-item-{ID}"><a href="{URL}" title="{TITLE}" class="product-image"><img src="{IMAGE}" alt="{TITLE}"></a><div class="product-details"><a href="javascript:void(0)" title="Remove This Item" class="btn-remove"><span class="icon_close"></span></a><p class="product-name"><a href="{URL}">{TITLE}</a></p><div class="cart-collateral">{QUANTITY} x <span class="price">{PRICE}</span></div></div></li>';
            e("#cartCount").text(n.item_count);
            e("#slidedown-cart .summary .price").html(Shopify.formatMoney(n.total_price, window.money_format));
            e("#slidedown-cart .mini-products-list").html("");
            if (n.item_count > 0) {
                for (var i = 0; i < n.items.length; i++) {
                    var s = r;
                    s = s.replace(/\{ID\}/g, n.items[i].id);
                    s = s.replace(/\{URL\}/g, n.items[i].url);
                    s = s.replace(/\{TITLE\}/g, n.items[i].title);
                    s = s.replace(/\{QUANTITY\}/g, n.items[i].quantity);
                    s = s.replace(/\{IMAGE\}/g, Shopify.resizeImage(n.items[i].image, "thumb"));
                    s = s.replace(/\{PRICE\}/g, Shopify.formatMoney(n.items[i].price, window.money_format));
                    e("#slidedown-cart .mini-products-list").append(s)
                }
                e("#slidedown-cart .btn-remove").click(function(n) {
                    n.preventDefault();
                    var r = e(this).parents(".item").attr("id");
                    r = r.match(/\d+/g);
                    Shopify.removeItem(r, function(e) {
                        t.doUpdateDropdownCart(e)
                    })
                });
                if (t.checkNeedToConvertCurrency()) {
                    Currency.convertAll(window.shop_currency, jQuery("#currencies").val(), "#slidedown-cart span.money", "money_format")
                }
            }
            t.checkItemsInDropdownCart()
        },
        checkNeedToConvertCurrency: function() {
            return window.show_multiple_currencies && Currency.currentCurrency != shopCurrency
        },
        loadQuickViewSlider: function(n, r) {
            var s = Shopify.resizeImage(n.featured_image, "large");
            r.find(".quickview-featured-image").append('<a href="' + n.url + '"><img src="' + s + '" title="' + n.title + '"/><div style="height: 100%; width: 100%; top:0px; left:-260px; z-index: 2000; position: absolute; display: none; background: url(' + window.loading_url + ') 50% 50% no-repeat;"></div></a>');
            if (n.images.length > 1) {
                var o = r.find(".more-view-wrapper ul");
                for (i in n.images) {
                    var u = Shopify.resizeImage(n.images[i], "large");
                    var a = Shopify.resizeImage(n.images[i], "small");
                    var f = '<li><a href="javascript:void(0)" data-image="' + u + '"><img src="' + a + '"  /></a></li>';
                    o.append(f)
                }
                o.find("a").click(function() {
                    var t = r.find(".quickview-featured-image img");
                    var n = r.find(".quickview-featured-image div");
                    if (t.attr("src") != e(this).attr("data-image")) {
                        t.attr("src", e(this).attr("data-image"));
                        n.show();
                        t.load(function(t) {
                            n.hide();
                            e(this).unbind("load");
                            n.hide()
                        })
                    }
                });
               
                 if (o.hasClass("quickview-more-views-owlslider")) {
                    t.initQuickViewMoreview(o)
                } else {
                    t.initQuickViewMoreview(o)
                }
              
            } else {
             
                r.find(".more-view-wrapper").remove();
               
            } 
        },
         closeEmailModalWindow: function() {
            if (e("#email-modal").length > 0 && e("#email-modal").is(":visible")) {
                e("#email-modal .modal-window").fadeOut(600, function() {
                    e("#email-modal .modal-overlay").fadeOut(600, function() {
                        e("#email-modal").hide();
                        e.cookie("emailSubcribeModal", "closed", {
                            expires: 1,
                            path: "/"
                        })
                    })
                })
            }
        },
        initQuickViewMoreview: function(t) {
            if (t) {
                t.owlCarousel({
                    navigation: true,
                    items: 4,
                    itemsDesktop: [1199, 4],
                    itemsDesktopSmall: [979, 3],
                    itemsTablet: [768, 3],
                    itemsTabletSmall: [540, 3],
                    itemsMobile: [360, 3]
                }).css("visibility", "visible")
            }
        },
      
     
        convertToSlug: function(e) {
            return e.toLowerCase().replace(/[^a-z0-9 -]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-")
        },
       
        createQuickViewVariants: function(t, n) {
            if (t.variants.length > 1) {
                for (var r = 0; r < t.variants.length; r++) {
                    var i = t.variants[r];
                    var s = '<option value="' + i.id + '">' + i.title + "</option>";
                    n.find("form.variants > select").append(s)
                }
                new Shopify.OptionSelectors("product-select-" + t.id, { product: t,  onVariantSelected: selectCallbackQuickview  });
               
                if (t.options.length == 1) {
                    e(".selector-wrapper:eq(0)").prepend("<label>" + t.options[0].name + "</label>")
                }
                n.find("form.variants .selector-wrapper label").each(function(n, r) {
                    e(this).html(t.options[n].name)
                })
            } else {
                n.find("form.variants > select").remove();
                var o = '<input type="hidden" name="id" value="' + t.variants[0].id + '">';
                n.find("form.variants").append(o)
            }
        },
       initProductMoreview: function() {
         if(e('.more-view-wrapper-owlslider').length > 0 )
         {
            e(".more-view-wrapper-owlslider ul").owlCarousel({
                navigation: true,
                items: 4,
                itemsDesktop: [1199, 5],
                itemsDesktopSmall: [979, 4],
                itemsTablet: [768, 4],
                itemsTabletSmall: [540, 4],
                itemsMobile: [360, 3]
            }).css("visibility", "visible")
            
            
         }    
        },
            closeQuickViewPopup: function() {
            e(".quick-view").fadeOut(500)
        }      
      
    }
})(jQuery)