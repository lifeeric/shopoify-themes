jQuery(document).ready(function($){
	
	"use strict";	
  
 
  (function(window){

    // check for touch
    if (Modernizr.touch) {

        // run the forEach on each figure element
        [].slice.call(document.querySelectorAll("figure")).forEach(function(el,i){

            // get close-caption button in variable
            var closeCaption = el.querySelector(".close-caption");

            // show the close-caption button
            classie.remove(closeCaption,"hidden");

            // check if the user moves a finger
            var fingerMove = false;
            el.addEventListener("touchmove",function(e){
                e.stopPropagation();
                fingerMove = true;
            });

            // always reset fingerMove to false on touch start
            el.addEventListener("touchstart",function(e){
                e.stopPropagation();
                fingerMove = false;
            });

            // add hover class if figure touchend and fingerMove is false
            el.addEventListener("touchend",function(e){
                e.stopPropagation();
                if (fingerMove == false) {
                    classie.add(el,"hover");
                }
            });

            // if close-caption button clicked, remove hover class
            closeCaption.addEventListener("touchend",function(e){
                e.preventDefault();
                e.stopPropagation();
                if (fingerMove == false) {
                    if (classie.has(el,"hover")) {
                        classie.remove(el,"hover");
                    }
                }
            });

        });

    }

})(window);
   var rel_count = $('#related-carousel .grid__item').length;
      if(rel_count > 3){ $('.related-nav').css('display','block');}
      else {$('.related-nav').css('display','none');}
  
  $("#related-carousel").owlCarousel({
         items: 3,
        itemsCustom: false,
        itemsDesktop: [1199, 3],
        itemsDesktopSmall: [980, 3],
        itemsTablet: [630, 2],
        itemsTabletSmall: false,
        itemsMobile: [479, 1],
        singleItem: false,
        itemsScaleUp: false,
        responsive: true,
        responsiveRefreshRate: 200,
        responsiveBaseWidth: window,
        autoPlay: false,
        stopOnHover: false,
        navigation: false,
	    autoWidth:true,
    	pagination:false
  });
    $(".related-nav .related-next-arrow").click(function(){
   $("#related-carousel").trigger('owl.next');
  })
  $(".related-nav .related-prev-arrow").click(function(){
   $("#related-carousel").trigger('owl.prev');
  })

  
 /*Toggle shortcode*/
	jQuery('.dt-sc-toggle').toggle(function(){ jQuery(this).addClass('active'); },function(){ jQuery(this).removeClass('active'); });
	jQuery('.dt-sc-toggle').click(function(){ jQuery(this).next('.dt-sc-toggle-content').slideToggle(); });
	jQuery('.dt-sc-toggle-frame-set').each(function(){
		var $this = jQuery(this),
		$toggle = $this.find('.dt-sc-toggle-accordion');
		
		$toggle.click(function(){
			if( jQuery(this).next().is(':hidden') ) {
				$this.find('.dt-sc-toggle-accordion').removeClass('active').next().slideUp();
				jQuery(this).toggleClass('active').next().slideDown();
			}
			return false;
		});
		
		//Activate First Item always
		$this.find('.dt-sc-toggle-accordion:first').addClass("active");
		$this.find('.dt-sc-toggle-accordion:first').next().slideDown();
	});/* Toggle Shortcode end*/
  

  
  
 
   	
  
  //TABS...
	if($('ul.tabs').length > 0) {
		$('ul.tabs').tabs('> .dt-sc-tabs_content');
	}
	
	if($('ul.dt-sc-tabs-frame').length > 0){
		$('ul.dt-sc-tabs-frame').tabs('> .dt-sc-tabs-frame-content');
	}
	
	if($('ul.tabs').length > 0) {
		$('ul.tabs').tabs('> .dt-sc-tabs_content');
	}
	
	if($('ul.dt-sc-tabs').length > 0){
		$('ul.dt-sc-tabs').tabs('> .dt-sc-tabs-content');
	}
  
	if($('.dt-sc-tabs-vertical-frame').length > 0){
	
		$('.dt-sc-tabs-vertical-frame').tabs('> .dt-sc-tabs-vertical-frame-content');
		
		$('.dt-sc-tabs-vertical-frame').each(function(){
			$(this).find("li:first").addClass('first').addClass('current');
			$(this).find("li:last").addClass('last');
		});
		
		$('.dt-sc-tabs-vertical-frame li').click(function(){
			$(this).parent().children().removeClass('current');
			$(this).addClass('current');
		});
		
	}
  
	//Custom tab jquery works...
	if($('.tabs-framed').length > 0){
	
		$('.custom-tabs-frame').tabs('> .custom-tabs-content').parent();
		
		$('.custom-tabs-frame').each(function(){
			$(this).find("li:first").addClass('first').addClass('current');
			$(this).find("li:last").addClass('last');
		});
		
		$('.custom-tabs-frame li').click(function(){
			$(this).parent().children().removeClass('current');
			$(this).addClass('current');
		});
	
	}
  
  
 // $("html").niceScroll({zindex:99999,cursorborder:"1px solid #424242"});
	
  
  //GO TO TOP...
	var offset = 220;	
	$(window).scroll(function() {
		if ($(this).scrollTop() > offset) {
			$('.back-to-top').fadeIn();
		} else {
			$('.back-to-top').fadeOut();
		}
	});
	
	$('.back-to-top').click(function(event) {
		event.preventDefault();
		$('html, body').animate({scrollTop: 0});
		return false;
	});
  
});

