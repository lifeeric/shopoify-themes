/*********************
rendomly number avialable user on current page
***********************/ 
jQuery(function($) {

   var min = 10;
   var max = 50;
   min = Math.ceil(min);
   max = Math.floor(max);
   var  r =  Math.floor(Math.random() * (max - min + 1)) + min;
   var inc = '0' ;

    var mytimeAgo = ['1', '2', '3', '4', '5','10', '-1', '-2', '-3', '-4', '-5'];
 
   var randomlytimeAgo='';
   var currentmytimeAgo='';

  var plus = ['10', '20', '15'];
 
   var randomlytimeAgo='';
   var currentmytimeAgo='';
   
   var range='';
   
    setInterval(function(){  
     
      
      randomlytimeAgo =  Math.floor(Math.random() * mytimeAgo.length); 
      
    
      currentmytimeAgo = mytimeAgo[randomlytimeAgo];
      
      
      r = parseInt(r)+parseInt(currentmytimeAgo) ; 
      
      
     
      if(r <=10 ){
      
         range =  Math.floor(Math.random() * plus.length);  
        
         var final =  plus[range];
        
        r=r+final;
      }
      if(r>300){
      
          range =  Math.floor(Math.random() * plus.length);  
        
         var final =  plus[range];
        
          r=r-final;

      
      }
                 
      jQuery("#dynamic_counter").html(r); 
  
  }, 2000);
  });


/******************
for read more 
******************/


$(function(){

  $('.product-description').readmore({
    collapsedHeight: 153,
    heightMargin: 16,
    moreLink: '<a href="javascript:void(0)" class="more_load">Read more</a>',
    lessLink: '<a href="javascript:void(0)" class="more_load">Less</a>'
  });
});

/*
$(document).on("click",".more_load",function(){

    
      $(".product-description").toggleClass('forscroll');
}) */


/*
$(document).ready(function() {
    
    // Configure/customize these variables.
  var showChar = 400;  // How many characters are shown by default
    var ellipsestext = "";
    var moretext = "Read More";
    var lesstext = "Less";
    var half_disc=$(".half_disc_readmore").html();

//  $('.product-description').each(function() {   });
        var content = $('.product-description').html();
 
 if(content.length > showChar) {  
  
          //  var c =content.substr(0, showChar);
           // var h =content.substr(showChar, content.length - showChar);
 
            var htmlfl ='<span class="halfText">'+half_disc + '</span><span class="moreellipses">' + ellipsestext+ '&nbsp;</span><span class="morecontent"><span class="fullText">' + content + '</span>&nbsp;&nbsp;<a href="javascript:" class="more_load">' + moretext + '</a></span>';
 
            $('.product-description').html(htmlfl);
      
 }
 
    $(".more_load").click(function(){
        if($(this).hasClass("less")) {
            $(this).removeClass("less");
            $(this).html(moretext);
        } else {
            $(this).addClass("less");
            $(this).html(lesstext);
        }
      //  $(this).parent().prev().toggle();
       // $(this).prev().toggle();
	    $('.moreellipses').toggle();
        $('.fullText').toggle();
		$('.halfText').toggle();
        return false;
    });
});	
*/


/************************

product thumb script

*************************/

 
    $(window).load(function(){
      $('.flexsliderproduct').flexslider({
        animation: "slide",
       slideshow: false, 
		controlNav: false,
        animationLoop: false,
		pauseOnHover:true, 
        itemWidth: 93,
        itemMargin: 10,
        pausePlay: false,
        start: function(slider){
          $('.slider').removeClass('loading');
        }
      });
    });



